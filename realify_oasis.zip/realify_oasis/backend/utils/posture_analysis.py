import cv2
import mediapipe as mp
import numpy as np

mp_pose = mp.solutions.pose
pose = mp_pose.Pose()

def analyze_posture(frame):
    image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = pose.process(image_rgb)
    feedback = []

    if results.pose_landmarks:
        landmarks = results.pose_landmarks.landmark
        left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
        left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP.value]
        left_knee = landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value]
        left_ankle = landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value]

        back_angle = calculate_angle(
            [left_shoulder.x, left_shoulder.y],
            [left_hip.x, left_hip.y],
            [left_knee.x, left_knee.y]
        )
        if back_angle < 150:
            feedback.append("Back angle too small: {:.2f}".format(back_angle))

        if left_knee.x > left_toe_x(landmarks):
            feedback.append("Knee over toe detected")

    return feedback

def calculate_angle(a, b, c):
    a, b, c = np.array(a), np.array(b), np.array(c)
    ba = a - b
    bc = c - b
    cosine_angle = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc))
    angle = np.arccos(np.clip(cosine_angle, -1.0, 1.0))
    return np.degrees(angle)

def left_toe_x(landmarks):
    return landmarks[mp_pose.PoseLandmark.LEFT_FOOT_INDEX.value].x